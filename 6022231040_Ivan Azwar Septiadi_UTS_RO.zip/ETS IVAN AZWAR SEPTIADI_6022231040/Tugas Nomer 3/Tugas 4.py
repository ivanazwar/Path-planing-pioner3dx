
import sys
import time
import sim
import keyboard
import math
import numpy as np


def connect_to_coppeliasim():
    sim.simxFinish(-1)
    clientID = sim.simxStart('127.0.0.1', 19997, True, True, 5000, 5)
    if clientID != -1:
        print('Connected to remote API server')
        return clientID
    else:
        print('Failed connecting to remote API server')
        sys.exit()


def get_robot_handle(clientID):
    res, robot_handle = sim.simxGetObjectHandle(clientID, '/PioneerP3DX', sim.simx_opmode_blocking)
    if res == sim.simx_return_ok:
        print('Pioneer P3DX handle:', robot_handle)
        return robot_handle
    else:
        print('Failed to get Pioneer P3DX handle')
        sys.exit()


def get_motor_handles(clientID, p3dx_handle):
    res, left_handle = sim.simxGetObjectHandle(clientID, '/PioneerP3DX/leftMotor', sim.simx_opmode_blocking)
    res, right_handle = sim.simxGetObjectHandle(clientID, '/PioneerP3DX/rightMotor', sim.simx_opmode_blocking)
    if res == sim.simx_return_ok:
        print('Pioneer P3DX motor handles obtained')
        motor_handles = (right_handle, left_handle)
        return motor_handles
    else:
        print('Failed to get Pioneer P3DX motor handles')
        sys.exit()


def get_sensors_handle(clientID):
    sensorsHandle = np.array([])
    for i in range(16):
        sensorHandle = sim.simxGetObjectHandle(
            clientID, '/PioneerP3DX/ultrasonicSensor[' + str(i) + ']', sim.simx_opmode_blocking)[1]
        _, _, _, _, _ = sim.simxReadProximitySensor(clientID, sensorHandle, sim.simx_opmode_streaming)
        sensorsHandle = np.append(sensorsHandle, sensorHandle)
        sensorsHandle = np.int32(sensorsHandle)
    return sensorsHandle


def get_distances(clientID, sensorsHandle):
    sensor_values = []
    for i in range(16):
        _, detectionState, detectedPoint, _, _ = sim.simxReadProximitySensor(clientID, sensorsHandle[i],
                                                                             sim.simx_opmode_buffer)
        if detectionState == True:
            distance = np.linalg.norm(detectedPoint)
        else:
            distance = float('inf')
        sensor_values.append(distance)
    return sensor_values


def get_robot_position(clientID, robot_handle):
    res, robot_position = sim.simxGetObjectPosition(clientID, robot_handle, -1, sim.simx_opmode_blocking)
    if res == sim.simx_return_ok:
        # print('Robot position:', robot_position[0],"," robot_position[1])
        return robot_position
    else:
        print('Failed to get robot position')
        sys.exit()


def get_robot_orientation(clientID, robot_handle):
    res, robot_orientation = sim.simxGetObjectOrientation(clientID, robot_handle, -1, sim.simx_opmode_blocking)
    if res == sim.simx_return_ok:
        # print('Robot orientation:', robot_orientation[2])
        return robot_orientation
    else:
        print('Failed to get robot orientation')
        sys.exit()


def get_disc_positions(clientID):
    disc_positions = []
    for i in range(15):
        res, disc_handle = sim.simxGetObjectHandle(clientID, '/Disc[' + str(i) + ']', sim.simx_opmode_blocking)


        if res == sim.simx_return_ok:
            res, disc_position = sim.simxGetObjectPosition(clientID, disc_handle, -1, sim.simx_opmode_blocking)
            if res == sim.simx_return_ok:
                print('waiting to get pos disc...')
                disc_positions.append(disc_position)
            else:
                print('Failed to get Disc position for Disc', i)
                sys.exit()
        else:
            print('Failed to get Disc handle for Disc', i)
            sys.exit()
    return disc_positions


def get_disc_orientations(clientID):
    disc_orientations = []
    for i in range(15):
        res, disc_handle = sim.simxGetObjectHandle(clientID, '/Disc[' + str(i) + ']', sim.simx_opmode_blocking)
        if res == sim.simx_return_ok:
            res, disc_orientation = sim.simxGetObjectOrientation(clientID, disc_handle, -1, sim.simx_opmode_blocking)
            if res == sim.simx_return_ok:
                print('Waiting to get disc orient.....')
                disc_orientations.append(disc_orientation)
            else:
                print('Failed to get Disc position for Disc ', i, )
                sys.exit()
        else:
            print('Failed to get Disc handle for Disc ', i, )
            sys.exit()
    return disc_orientations


def set_motor_obstacle_avoidence(clientID, motor_handles, leftMotorVelocity, rightMotorVelocity):
    _ = sim.simxSetJointTargetVelocity(clientID, motor_handles[1], leftMotorVelocity, sim.simx_opmode_oneshot)
    _ = sim.simxSetJointTargetVelocity(clientID, motor_handles[0], rightMotorVelocity, sim.simx_opmode_oneshot)


def set_robot_motion(clientID, motor_handles, motors_velocity):
    _ = sim.simxSetJointTargetVelocity(clientID, motor_handles[0], motors_velocity[0], sim.simx_opmode_oneshot)
    _ = sim.simxSetJointTargetVelocity(clientID, motor_handles[1], motors_velocity[1], sim.simx_opmode_oneshot)


def stop_robot(clientID, motor_handles):
    _ = sim.simxSetJointTargetVelocity(clientID, motor_handles[0], 0, sim.simx_opmode_oneshot)
    _ = sim.simxSetJointTargetVelocity(clientID, motor_handles[1], 0, sim.simx_opmode_oneshot)


clientID = connect_to_coppeliasim()
robot_handle = get_robot_handle(clientID)
sensors_handle = get_sensors_handle(clientID)
motor_handles = get_motor_handles(clientID, robot_handle)

velo_init = (0.0, 0.0)
samp_time, n = 0.1, 1.0
time_start = time.time()
position_tol = 0.2
orientation_tol = 0.3
k_1 = 0.5
k_2 = 0.5
k_3 = 0.5
R = 1
L = 1
vnorm = 5
flag = 0

print("scanning disc pos and Robot waiting to start")

disc_positions = get_disc_positions(clientID)
disc_orientations = get_disc_orientations(clientID)

safe_distance = 0.2

print("RUN")

while (True):
    t_now = time.time() - time_start
    if t_now >= samp_time * n:
        object_distances = get_distances(clientID, sensors_handle)

        robot_position = get_robot_position(clientID, robot_handle)
        robot_orientation = get_robot_orientation(clientID, robot_handle)

        x_act = robot_position[0]
        y_act = robot_position[1]
        g_act = robot_orientation[2]

        x_ref = disc_positions[flag][0]
        y_ref = disc_positions[flag][1]
        g_ref = disc_orientations[flag][2]

        e_x = x_ref - x_act
        e_y = y_ref - y_act
        e_g = g_ref - g_act
        theta = math.atan(e_y / e_x)

        print("Goal = Disc", flag)
        print('Get disc', flag, x_ref,y_ref)

        if object_distances[4] <= safe_distance or object_distances[6] <= safe_distance:
            set_motor_obstacle_avoidence(clientID, motor_handles, 0, 0.5)
            print("Obstacle detected in front right")
        elif object_distances[1] <= safe_distance or object_distances[3] <= safe_distance:
            set_motor_obstacle_avoidence(clientID, motor_handles, 0.5, 0)
            print("Obstacle detected in front left")
        else:
            if (abs(e_x) <= position_tol) and (abs(e_y) <= position_tol):
                x_c = 0
                y_c = 0
                if flag == 12:
                    if abs(e_g) >= orientation_tol:
                        g_c = k_3 * (g_ref - g_act)
                        if abs(e_g) <= orientation_tol:
                            g_c = 0
                    else:
                        stop_robot(clientID, motor_handles)
                        time.sleep(5)
                        flag += 1
                elif flag == 14:
                    g_c = 0
                    flag = 0
                else:
                    # sim.simxFinish(clientID)
                    g_c = 0
                    flag += 1

            else:
                x_c = k_1 * (x_ref - x_act)
                y_c = k_2 * (y_ref - y_act)
                g_c = theta - g_act

            matrix_A = np.array([[(R / 2) * math.cos(theta), (R / 2) * math.cos(theta)],
                                 [(R / 2) * math.sin(theta), (R / 2) * math.sin(theta)],
                                 [R / (2 * L), -R / (2 * L)]])

            matrix_B = np.array([[x_c],
                                 [y_c],
                                 [g_c]])

            inverse_A = np.linalg.pinv(matrix_A)
            velocity_gen = np.dot(inverse_A, matrix_B)
            velocity_max = max(velocity_gen[1], velocity_gen[0])
            if abs(velocity_max) > vnorm:
                velocity_rn = (vnorm / velocity_max) * velocity_gen[0]
                velocity_ln = (vnorm / velocity_max) * velocity_gen[1]
            else:
                velocity_rn = velocity_gen[0]
                velocity_ln = velocity_gen[1]
            velocity_output = (velocity_rn, velocity_ln)
            motors_velocity = velocity_output
            set_robot_motion(clientID, motor_handles, motors_velocity)

        n += 1.0
        if keyboard.is_pressed('esc'): break
sim.simxFinish(clientID)
print('Connection closed')
